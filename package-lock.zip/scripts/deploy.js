const hre = require("hardhat");

async function main() {
  const NFTMarketPlace = await hre.ethers.getContractFactory("NFTMarketPlace");
  const nFTMarketPlace = await NFTMarketPlace.deploy();

  await nFTMarketPlace.deployed();

  console.log(
    `MarketPlace deployed with  ${nFTMarketPlace.address}`
  );

  const NFTErc721a = await hre.ethers.getContractFactory("NFTErc721a");
  const nFTErc721a = await NFTErc721a.deploy(nFTMarketPlace.address,1000000000);

  await nFTErc721a.deployed();

  console.log(
    `nFTErc721a deployed with  ${nFTErc721a.address}`
  );


}

// We recommend this pattern to be able to use async/await everywhere
// and properly handle errors.
main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
